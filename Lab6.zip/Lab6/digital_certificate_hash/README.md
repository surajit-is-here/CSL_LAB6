# Digital Hash Calculator

## 1. Introduction

This project implements a Digital Hash Calculator that calculates cryptographic hash values for both text input and files.

The application supports three hashing algorithms:

* MD5
* SHA-256
* SHA3-256

The application can process both text files and binary files such as images, PDFs, ZIP files, etc.

---

## 2. Objective

The objective of this project is to understand and implement cryptographic hash functions and observe how different inputs produce different hash values.

The project also demonstrates hashing of files of different sizes, including approximately 10 KB and 10 MB files.

---

## 3. Technologies Used

* Programming Language: Python
* GUI Framework: Tkinter
* Hash Library: Python hashlib
* Operating System: Windows / macOS / Linux

No external hashing library is required because Python provides the `hashlib` module.

---

## 4. Hashing Algorithms

### MD5

MD5 produces a 128-bit hash value, normally represented as 32 hexadecimal characters.

Although MD5 is still useful for checksums and demonstrations, it is not considered secure for modern cryptographic applications because collision attacks are known.

### SHA-256

SHA-256 belongs to the SHA-2 family and produces a 256-bit hash value represented by 64 hexadecimal characters.

SHA-256 is widely used in security and cryptographic applications.

### SHA3-256

SHA3-256 belongs to the SHA-3 family and produces a 256-bit hash value represented by 64 hexadecimal characters.

SHA-3 uses a different internal construction from SHA-2 and is based on the Keccak algorithm.

---

## 5. Features

The application provides the following features:

1. Calculate MD5 hash of text.
2. Calculate SHA-256 hash of text.
3. Calculate SHA3-256 hash of text.
4. Select a file using a file browser.
5. Calculate hashes of text files.
6. Calculate hashes of binary files.
7. Process large files using chunks instead of loading the complete file into memory.
8. Display the calculated hash values in the GUI.

---

## 6. Project Structure

```text
DigitalHashCalculator/
│
├── hash_app.py
├── generate_test_files.py
├── test_10KB.txt
├── test_10MB.txt
├── README.md
└── screenshots/
    ├── text_hash.png
    ├── 10kb_hash.png
    └── 10mb_hash.png
```

---

## 7. How to Run

First, make sure Python is installed.

Check the Python version:

```bash
python --version
```

Generate the test files:

```bash
python generate_test_files.py
```

Then run the application:

```bash
python hash_app.py
```

The Digital Hash Calculator GUI will open.

---

## 8. Text Input Test

A message containing the student's ID was entered into the application.

Example:

```text
My Student ID is YOUR_STUDENT_ID
```

The application generated MD5, SHA-256 and SHA3-256 hash values for the message.

The actual student ID should be replaced in the above example before submission.

---

## 9. File Testing

Two test files were generated:

### 10 KB File

```text
File: test_10KB.txt
Size: approximately 10 KB
```

The application was used to calculate its MD5, SHA-256 and SHA3-256 values.

### 10 MB File

```text
File: test_10MB.txt
Size: approximately 10 MB
```

The application was used to calculate its MD5, SHA-256 and SHA3-256 values.

---

## 10. Test Results

| Test | Input                         | MD5        | SHA-256    | SHA3-256   |
| ---- | ----------------------------- | ---------- | ---------- | ---------- |
| 1    | Message containing Student ID | Add result | Add result | Add result |
| 2    | test_10KB.txt                 | Add result | Add result | Add result |
| 3    | test_10MB.txt                 | Add result | Add result | Add result |

The actual hash values were obtained by running the application.

---

## 11. Binary File Testing

The application opens files in binary mode (`rb`). Therefore, it can calculate hashes for both text and binary files.

For example, an image or PDF can be selected using the Browse File option and its hash values can be calculated.

---

## 12. Why Hashing Is Useful

A hash function converts input data into a fixed-length value.

For example:

```text
Input Data
    |
    v
Hash Function
    |
    v
Fixed-Length Hash
```

If even a small part of the input changes, the resulting hash value changes significantly.

This property makes hashing useful for:

* Data integrity
* File verification
* Digital signatures
* Password storage
* Digital certificates
* Message authentication

---

## 13. Relation to Digital Certificates

Digital certificates use cryptographic techniques to establish trust between entities.

Hash functions are an important component of digital signatures and certificate verification.

A simplified process is:

```text
Data
  |
  v
Hash Function
  |
  v
Hash Value
  |
  v
Digital Signature
```

The receiver can verify the signature and ensure that the data has not been modified.

---

## 14. Conclusion

The Digital Hash Calculator successfully calculates MD5, SHA-256 and SHA3-256 hash values for text and files.

The application was tested using a message containing the student's ID and files of approximately 10 KB and 10 MB.

The project demonstrates the importance of cryptographic hash functions in data integrity, file verification and digital security.
