import tkinter as tk
from tkinter import filedialog, messagebox
import hashlib
import os


def calculate_text_hashes():
    text = text_input.get("1.0", tk.END).rstrip("\n")

    if not text:
        messagebox.showwarning("Input Required", "Please enter some text.")
        return

    data = text.encode("utf-8")

    md5_hash = hashlib.md5(data).hexdigest()
    sha256_hash = hashlib.sha256(data).hexdigest()
    sha3_hash = hashlib.sha3_256(data).hexdigest()

    display_results(
        f"Input Type: Text\n\n"
        f"MD5:\n{md5_hash}\n\n"
        f"SHA-256:\n{sha256_hash}\n\n"
        f"SHA3-256:\n{sha3_hash}"
    )


def calculate_file_hashes(filename):
    md5 = hashlib.md5()
    sha256 = hashlib.sha256()
    sha3 = hashlib.sha3_256()

    try:
        with open(filename, "rb") as file:
            while True:
                chunk = file.read(8192)

                if not chunk:
                    break

                md5.update(chunk)
                sha256.update(chunk)
                sha3.update(chunk)

        file_size = os.path.getsize(filename)

        if file_size < 1024 * 1024:
            size_text = f"{file_size / 1024:.2f} KB"
        else:
            size_text = f"{file_size / (1024 * 1024):.2f} MB"

        display_results(
            f"Input Type: File\n"
            f"File: {os.path.basename(filename)}\n"
            f"Size: {size_text}\n\n"
            f"MD5:\n{md5.hexdigest()}\n\n"
            f"SHA-256:\n{sha256.hexdigest()}\n\n"
            f"SHA3-256:\n{sha3.hexdigest()}"
        )

    except Exception as e:
        messagebox.showerror("Error", f"Could not read the file.\n\n{e}")


def select_file():
    filename = filedialog.askopenfilename(
        title="Select a file"
    )

    if filename:
        file_path_label.config(text=filename)
        calculate_file_hashes(filename)


def display_results(result):
    result_text.config(state=tk.NORMAL)
    result_text.delete("1.0", tk.END)
    result_text.insert(tk.END, result)
    result_text.config(state=tk.DISABLED)


# ---------------- GUI ----------------

root = tk.Tk()
root.title("Digital Hash Calculator")
root.geometry("750x650")
root.resizable(False, False)

title_label = tk.Label(
    root,
    text="Digital Hash Calculator",
    font=("Arial", 22, "bold")
)
title_label.pack(pady=15)


# Text section
text_label = tk.Label(
    root,
    text="Enter Text:",
    font=("Arial", 13, "bold")
)
text_label.pack(anchor="w", padx=30)

text_input = tk.Text(
    root,
    height=5,
    width=80,
    font=("Arial", 11)
)
text_input.pack(padx=30, pady=8)

text_button = tk.Button(
    root,
    text="Calculate Text Hash",
    command=calculate_text_hashes,
    font=("Arial", 11, "bold"),
    padx=15,
    pady=5
)
text_button.pack(pady=5)


# File section
file_label = tk.Label(
    root,
    text="Or select a file:",
    font=("Arial", 13, "bold")
)
file_label.pack(anchor="w", padx=30, pady=(15, 5))

browse_button = tk.Button(
    root,
    text="Browse File",
    command=select_file,
    font=("Arial", 11, "bold"),
    padx=20,
    pady=5
)
browse_button.pack()

file_path_label = tk.Label(
    root,
    text="No file selected",
    font=("Arial", 10),
    wraplength=650
)
file_path_label.pack(pady=8)


# Results section
result_label = tk.Label(
    root,
    text="Hash Results:",
    font=("Arial", 13, "bold")
)
result_label.pack(anchor="w", padx=30, pady=(10, 5))

result_text = tk.Text(
    root,
    height=15,
    width=80,
    font=("Courier New", 10)
)
result_text.pack(padx=30, pady=5)
result_text.config(state=tk.DISABLED)


root.mainloop()