# generate_test_files.py

# Create a 10 KB text file
with open("test_10KB.txt", "wb") as file:
    file.write(b"A" * (10 * 1024))


# Create a 10 MB text file
with open("test_10MB.txt", "wb") as file:
    file.write(b"A" * (10 * 1024 * 1024))


print("Test files created successfully!")

print("test_10KB.txt  -> 10 KB")
print("test_10MB.txt  -> 10 MB")